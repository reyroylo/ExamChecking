import java.io.Serializable;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ShapeClient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12345)) {
            System.out.println("Connected to server.");
            ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("Enter the shape type (circle/rectangle) or Q to quit:");
                String shapeType = scanner.nextLine();

                if (shapeType.equalsIgnoreCase("Q")) {
                    outputStream.writeObject(null); // Signal to the server to close connection
                    break;
                }

                GeometricObject shape = null;
                if (shapeType.equalsIgnoreCase("circle")) {
                    System.out.print("Enter the radius of the circle: ");
                    double radius = scanner.nextDouble();
                    scanner.nextLine();  // Consume the newline character
                    shape = new Circle(radius);
                } else if (shapeType.equalsIgnoreCase("rectangle")) {
                    System.out.print("Enter the width of the rectangle: ");
                    double width = scanner.nextDouble();
                    System.out.print("Enter the height of the rectangle: ");
                    double height = scanner.nextDouble();
                    scanner.nextLine();  // Consume the newline character
                    shape = new Rectangle(width, height);
                }

                if (shape != null) {
                    // Send the shape object to the server
                    outputStream.writeObject(shape);
                    // Receive the area from the server
                    double area = (Double) inputStream.readObject();
                    System.out.println("The area of the " + shapeType + " is: " + area);
                } else {
                    System.out.println("Invalid shape type. Please enter 'circle' or 'rectangle'.");
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}



