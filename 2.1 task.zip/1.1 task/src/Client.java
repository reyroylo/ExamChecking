import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12345);
             ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connected to the server.");
            System.out.println("Enter 'Q' to quit.");

            while (true) {
                System.out.println("Choose a shape (Circle/Rectangle): ");
                String shapeType = scanner.nextLine();

                if (shapeType.equalsIgnoreCase("Q")) {
                    output.writeObject("Q");
                    System.out.println("Closing connection...");
                    break;
                }

                Shape shape = null;

                if (shapeType.equalsIgnoreCase("Circle")) {
                    System.out.print("Enter radius: ");
                    double radius = scanner.nextDouble();
                    shape = new Circle(radius);
                } else if (shapeType.equalsIgnoreCase("Rectangle")) {
                    System.out.print("Enter width: ");
                    double width = scanner.nextDouble();
                    System.out.print("Enter height: ");
                    double height = scanner.nextDouble();
                    shape = new Rectangle(width, height);
                } else {
                    System.out.println("Invalid shape. Try again.");
                    continue;
                }

                scanner.nextLine(); // Clear buffer
                output.writeObject(shape);
                String response = (String) input.readObject();
                System.out.println(response);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
