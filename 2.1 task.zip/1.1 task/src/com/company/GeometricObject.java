package com.company;

import java.io.Serializable;

abstract class GeometricObject implements Serializable {
    private static final long serialVersionUID = 1L;

    public abstract double calculateArea();
}

class Circle extends GeometricObject {
    private static final long serialVersionUID = 1L;
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    public double getRadius() {
        return radius;
    }
}

class Rectangle extends GeometricObject {
    private static final long serialVersionUID = 1L;
    private double width;
    private double height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public double calculateArea() {
        return width * height;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }
}
