package com.company;

import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server is running... Waiting for client connection.");

            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     ObjectInputStream input = new ObjectInputStream(clientSocket.getInputStream());
                     ObjectOutputStream output = new ObjectOutputStream(clientSocket.getOutputStream())) {

                    System.out.println("Client connected.");

                    while (true) {
                        Object received = input.readObject();
                        if (received instanceof String && received.equals("Q")) {
                            System.out.println("Client disconnected.");
                            break;
                        }

                        if (received instanceof Shape) {
                            Shape shape = (Shape) received;
                            double area = shape.calculateArea();
                            output.writeObject("Area: " + area);
                        }
                    }
                } catch (EOFException e) {
                    System.out.println("Client closed the connection.");
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

interface Shape extends Serializable {
    double calculateArea();
}

class Circle implements Shape {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }
}

class Rectangle implements Shape {
    private double width, height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public double calculateArea() {
        return width * height;
    }
}

